# Supplementary scientific audit results

Raw reconciliation: **PASS** across 192 rows and 624 real requests

There are 2 constructed captures from four fixed recipe adaptations and two seeds each
Conditions and repeated requests from a capture are correlated and are not additional independent samples

Both exact formulations were attempted on 8 cases with 0 optimum disagreements and 0 unproved cases

Unexpected recovery outcomes: 0
Expected blocked requests and zero-saving conditions remain in the raw evidence and summary

The exact minimum policies report infeasible below their minimum byte requirement and do not claim to maximize partial coverage
The complete-only latency plot must be read with the coverage plot to avoid a successful-only comparison

| Method | Exact / requests over the full declared grid | Complete conditions / conditions |
|---|---:|---:|
| RecoverML_exact | 45 / 78 | 17 / 24 |
| scenario_exact | 45 / 78 | 17 / 24 |
| robust_greedy | 52 / 78 | 16 / 24 |
| robust_local | 53 / 78 | 17 / 24 |
| HYPPO_rank | 44 / 78 | 14 / 24 |
| HYPPO_frequency | 44 / 78 | 14 / 24 |
| HELIX_rule | 42 / 78 | 14 / 24 |
| target_snapshots | 42 / 78 | 16 / 24 |

These pooled counts describe this fixed matrix and do not establish population significance
Costs include manifest parsing and grounded planning and model loading or retraining and dependency recovery
One trial per request does not establish stable tail-latency estimates or device-level I/O or energy

The source snapshots and protocol hash and full planners and sensitivity rows are included
The recipes have no deliberately inserted equal-output producers and remain constructed histories rather than observed production histories
